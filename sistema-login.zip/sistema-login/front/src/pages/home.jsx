import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../App.css'

function Home() {
    return(
    <div>
        <h1>Página Inicial</h1>
        <h2>Júlia Pereira</h2>
    </div>
    )
}

export default Home;